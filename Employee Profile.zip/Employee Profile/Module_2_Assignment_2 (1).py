#!/usr/bin/env python
# coding: utf-8

# In[1]:


# Module 2 Assignment by Kingsley Edionwe
# Learners ID: 157398
# Employee Salary Function.

import pandas as pd
import numpy as np
import seaborn as sns

# Declaration and loading the CSV file into a DataFrame

def get_employee_details(employee_name, file_path):
    
    try:
        df = pd.read_csv(file_path)
    except FileNotFoundError:
        print("The specified file was not found.")
        return None

# This Searches for the employee in the DataFrame

    employee_details = df[df['Name'].str.lower() == employee_name.lower()]

    if employee_details.empty:
        print("Employee not found.")
        return None
    else:
        return employee_details
    
def process_salary(employee_details):
    
# Picking values from the column named 'Salary'
    salary = employee_details['Salary'].values[0]
    
# Processing: calculates annual salary assuming monthly salary
    annual_salary = salary * 12
    return annual_salary

def export_employee_details(employee_details, output_file):

# Export the employee details to a new CSV file

    employee_details.to_csv(output_file, index=False)
    print(f"Employee details exported to {output_file}")

def main():
    file_path = r"C:\Users\kings\OneDrive\Desktop\Python\Module 2\Total.csv"
    employee_name = input("Enter the employee's name: ")
    
    employee_details = get_employee_details(employee_name, file_path)
    
    if employee_details is not None:
        print("Employee Details:")
        print(employee_details)
        annual_salary = process_salary(employee_details)
        print(f"Annual Salary for {employee_name}: {annual_salary}")
        
        output_file = f"{employee_name}_details.csv"
        export_employee_details(employee_details, output_file)

if __name__ == "__main__":
    main()


# In[ ]:




