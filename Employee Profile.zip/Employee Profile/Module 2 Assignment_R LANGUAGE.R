library(zip)

unzip("C:/Users/kings/OneDrive/Desktop/Python/Module 2/Employee Profile.zip", exdir = "C:/Users/kings/OneDrive/Desktop/Python/Module 2/Employee Profile")

file_path <- "C:/Users/kings/OneDrive/Desktop/Python/Module 2/Employee Profile/NATHANIEL FORD_details.csv"
details <- readLines(file_path)
cat(details, sep = "\n")

